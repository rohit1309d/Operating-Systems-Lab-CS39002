#!/bin/sh
mkdir 1.b.files.out

cat ./1.b.files/* > 1.b.txt
sort -nr 1.b.txt > 1.b.out.txt
rm 1.b.txt

cd ./1.b.files

for FILE in *
do
    sort -r -n $FILE > ../1.b.files.out/$FILE
done