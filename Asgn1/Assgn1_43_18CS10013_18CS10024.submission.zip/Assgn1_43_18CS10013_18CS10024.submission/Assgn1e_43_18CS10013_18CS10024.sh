#!/bin/sh
< /dev/urandom tr -dc _A-Za-z0-9 | head -c${1:-16}
echo