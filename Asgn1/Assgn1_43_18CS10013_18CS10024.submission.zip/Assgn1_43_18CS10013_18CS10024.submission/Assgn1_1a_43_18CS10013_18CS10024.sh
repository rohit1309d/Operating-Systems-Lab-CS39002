#!/bin/sh
IFS=','  
read -a Numarr <<< $1

len=${#Numarr[*]}
g=${Numarr[0]#-}

if [ $len -gt 10 ]
then
    echo "There are more than 10 numbers"
else
    for (( counter=1; counter<len; counter++ ))
    do
        m=$g

        if [ ${Numarr[counter]#-} -lt $m ]
        then
            m=${Numarr[counter]#-}
        fi

        while [ $m -ne 0 ]
        do
            x=`expr $g % $m`
            y=`expr ${Numarr[counter]#-} % $m`

            if [ $x -eq 0 -a $y -eq 0 ]
            then
                g=$m
                break
            fi

            m=`expr $m - 1`

        done
    done

    echo $g
fi