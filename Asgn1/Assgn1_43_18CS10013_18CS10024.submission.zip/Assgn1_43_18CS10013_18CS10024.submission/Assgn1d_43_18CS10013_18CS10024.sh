#!/bin/sh

archive="$(readlink -f "$(echo "$*" | cut -d' ' -f2)")"

[ "$archive" = "" ] && printf "Give archive to extract as argument.\\n" && exit

case "$archive" in
    *.tar.bz2|*.tbz2) tar xvjf "$archive" ;;
    *.tar.gz|*.tgz) tar xfvz "$archive" ;;
    *.bz2) bunzip2 -k "$archive" ;;
    *.rar) echo "If an error is occured then run this command \nsudo apt install unrar \n"; unrar e "$archive" ;;
    *.gz) gunzip -k "$archive" ;;
    *.tar) tar xvf "$archive" ;;
    *.zip) unzip "$archive" ;;
    *.Z) uncompress -k "$archive" ;;
    *.7z) echo "If an error is occured then run this command \nsudo apt install p7zip-full \n"; 7z x "$archive" ;;
    *) printf "extract: '%s' - unknown archive method\\n" "$archive" ;;
esac