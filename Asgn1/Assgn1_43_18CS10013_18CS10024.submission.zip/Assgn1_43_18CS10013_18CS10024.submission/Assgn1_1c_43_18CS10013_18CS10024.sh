#!/bin/sh
maxcol=$(head -n 1 $1 | wc -w)
if [ $2 -gt $maxcol ]
then 
    echo "Valid column number not entered"
    exit 
elif [ $2 -lt 1 ]
then
    echo "Valid column number not entered"
    exit 
fi
awk -v col=$2 '{print tolower($col)}' $1 | sort | uniq -c | awk '{print $2 " " $1}' > "1c_output _"$2"_column.freq"
awk -v col=$2 '{print tolower($col)}' $1 | sort | uniq -c | sort -nr | awk '{print $2 " " $1}' > "1e_output _"$2"_column.freq"
